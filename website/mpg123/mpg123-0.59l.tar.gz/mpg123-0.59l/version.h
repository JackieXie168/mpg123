char *prgVersion = "0.59l";
char *prgDate = "1997/08/02";
char *prgName;
