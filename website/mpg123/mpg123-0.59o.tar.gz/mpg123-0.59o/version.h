char *prgVersion = "0.59o";
char *prgDate = "1998/Feb/08";
char *prgName;
