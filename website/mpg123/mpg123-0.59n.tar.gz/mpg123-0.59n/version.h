char *prgVersion = "0.59n";
char *prgDate = "1998/Jan/04";
char *prgName;
