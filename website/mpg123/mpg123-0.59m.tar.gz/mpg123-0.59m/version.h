char *prgVersion = "0.59m+";
char *prgDate = "1997/10/07";
char *prgName;
