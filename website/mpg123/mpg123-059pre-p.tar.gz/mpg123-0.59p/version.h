char *prgVersion = "0.59p";
char *prgDate = "1998/Nov/15";
char *prgName;
