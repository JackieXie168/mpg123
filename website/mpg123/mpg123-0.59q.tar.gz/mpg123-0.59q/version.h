char *prgVersion = "0.59q";
char *prgDate = "1999/Jan/26";
char *prgName;
