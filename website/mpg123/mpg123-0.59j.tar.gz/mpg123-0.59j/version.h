char *prgVersion = "0.59j";
char *prgDate = "97/06/22";
char *prgName;

