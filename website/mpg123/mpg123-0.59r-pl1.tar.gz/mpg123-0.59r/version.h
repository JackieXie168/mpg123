char *prgVersion = "0.59r";
char *prgDate = "1999/Jun/15";
char *prgName;
