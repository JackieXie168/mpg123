char *prgVersion = "0.59s-mh4";
char *prgDate = "2000/Oct/27";
char *prgName;
