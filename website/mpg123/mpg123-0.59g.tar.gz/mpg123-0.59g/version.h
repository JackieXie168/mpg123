char *prgVersion = "0.59g";
char *prgDate = "97/04/23";
char *prgName;

