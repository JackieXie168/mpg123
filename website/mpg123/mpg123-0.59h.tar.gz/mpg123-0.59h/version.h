char *prgVersion = "0.59h";
char *prgDate = "97/04/30";
char *prgName;

