char *prgVersion = "0.59i";
char *prgDate = "97/06/13";
char *prgName;

